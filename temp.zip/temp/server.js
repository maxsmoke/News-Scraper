const MONGOOSE = require("mongoose");
const EXPRESS = require("express");
const BODYPARSER = require("body-parser");
const LOGGER = require("morgan");



//scraping tools
const AXIOS = require("axios");
const CHEERIO = require("cheerio");

//database
let DB = require("./models/index");

const PORT = 3000;

//initialize express
const APP = EXPRESS();

//middleware
APP.use(logger("dev"));
APP.use(BODYPARSER.urlencoded({extended: true}));
APP.use(EXPRESS.static("public"));

MONGOOSE.connect("mongod://localhost/webScrape");


